<!DOCTYPE html> <html> 
<head>
<title>test</title> 
<meta charset="UTF-8" /> 
</head> 

<body> 
<p>
Veuillez rentrer le numéro de la vanne (1, 2, 3 ou 4). <br />
Et la valeur de la vanne (0= fermer, 1= ouvert).
</p>
<form method="post" action="pompe.php"> 
<input type="password" name="mdp" /><br /> 
<input type="submit" /> 
</form> 
</body>
</html> 