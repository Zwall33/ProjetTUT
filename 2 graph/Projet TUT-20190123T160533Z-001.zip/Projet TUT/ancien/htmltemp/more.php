<!DOCTYPE html>

<head>
	<meta charset="utf-8">
	<link href="index.css" rel="stylesheet" type="text/css">
	<title>about</title>
</head>

<body>
<!--------------menu deroulant------------->
	<?php include("menu.html"); ?>

<header>
	about this project
</header>

<section class="article">
		<p>
		Notre équipe d'étudiants de l'iut remercie:<br />
		les iut (geii, mp) de gradignan,ainsi que leurs professeurs.<br />
		
		</p>
		
		

</section>
</body>	

