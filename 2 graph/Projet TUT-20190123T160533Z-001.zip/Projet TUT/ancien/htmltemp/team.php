<!DOCTYPE html>

<head>
	<meta charset="utf-8">
	<link href="index.css" rel="stylesheet" type="text/css">
	<title>team</title>
</head>

<body>

<!--------------menu deroulant------------->
	<?php include("menu.html"); ?>

<header>
	team
</header>

<section class="article">
		<p>
		Notre équipe est formé de cinq étudiants de bordeaux.<br />
		Nous sommes chacun spécialisés dans notre domian:<br />
		<ul>
			<li>webmester</li>
			<li>administrateur réseaux</li>
			<li>administrateur données</li>
			<li>technicienne mesures</li>
			<li>technicienne météorologique</li>
		</ul>
		</p>
		
		

</section>
</body>	

